// Cart Page Interactivity - Load cart from localStorage

// Load and display cart items from localStorage
function loadCartItems() {
    const cartItems = document.getElementById('cartItems');
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h2>Your cart is empty</h2>
                <p>Add some beautiful flowers to get started!</p>
                <a href="{% url 'shop' %}">Continue Shopping</a>
            </div>
        `;
        return;
    }
    
    cartItems.innerHTML = '';
    cart.forEach((item, index) => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="item-image">
                <img src="${item.image}" alt="${item.name}">
                <span class="item-badge">${item.badge || 'Product'}</span>
            </div>
            <div class="item-details">
                <h3 class="item-name">${item.name}</h3>
                <p class="item-description">${item.description}</p>
                <div class="quantity-control">
                    <button class="qty-btn" onclick="decreaseQty(${index})">−</button>
                    <input type="number" value="${item.quantity}" class="qty-input" readonly>
                    <button class="qty-btn" onclick="increaseQty(${index})">+</button>
                </div>
            </div>
            <div class="item-price">
                <span class="unit-price">₱${item.unitPrice.toLocaleString()}</span>
                <span class="total-price">₱${(item.unitPrice * item.quantity).toLocaleString()}</span>
            </div>
            <button class="remove-btn" onclick="removeItem(${index})"><i class="fas fa-trash"></i></button>
        `;
        cartItems.appendChild(cartItem);
    });
    
    updateOrderSummary();
}

// Decrease quantity
function decreaseQty(index) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart[index] && cart[index].quantity > 1) {
        cart[index].quantity--;
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCartItems();
    }
}

// Increase quantity
function increaseQty(index) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart[index]) {
        cart[index].quantity++;
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCartItems();
    }
}

// Remove item from cart
function removeItem(index) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    loadCartItems();
}

// Update order summary
function updateOrderSummary() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    let totalItems = 0;
    let subtotal = 0;
    
    cart.forEach(item => {
        totalItems += item.quantity;
        subtotal += item.unitPrice * item.quantity;
    });
    
    const deliveryFee = 150;
    const total = subtotal + deliveryFee;
    
    document.getElementById('itemCountLabel').textContent = `Subtotal (${totalItems} items)`;
    document.getElementById('subtotalPrice').textContent = `₱${subtotal.toLocaleString()}`;
    document.getElementById('totalAmount').textContent = `₱${total.toLocaleString()}`;
}

// Initialize cart on page load
function cartInitialize() {
    loadCartItems();
    
    const checkoutBtn = document.querySelector('.checkout-btn');
    if (checkoutBtn) {
        checkoutBtn.addEventListener('click', proceedToCheckout);
    }
    
    console.log('Cart page initialized successfully');
}

// Proceed to checkout
function proceedToCheckout() {
    const note = document.getElementById('note').value;
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    if (cart.length === 0) {
        alert('Your cart is empty. Please add items before checking out.');
        return;
    }
    
    console.log('Proceeding to checkout with note:', note);
    alert('Proceeding to checkout! Special note: ' + (note || 'None'));
    // You would typically redirect to checkout page here
    // window.location.href = '/checkout';
}

// Add fade out animation
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeOutDown {
        from {
            opacity: 1;
            transform: translateY(0);
        }
        to {
            opacity: 0;
            transform: translateY(20px);
        }
    }
`;
document.head.appendChild(style);

// Run initialization when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', cartInitialize);
} else {
    cartInitialize();
}
